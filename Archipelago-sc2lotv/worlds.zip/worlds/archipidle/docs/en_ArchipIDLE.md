# ArchipIDLE

## What is this game?

ArchipIDLE is the 2022 Archipelago April Fools' Day joke. It is an idle game that sends a location check every
thirty seconds, up to one hundred checks.

## Where is the settings page?

The [player settings page for this game](../player-settings) contains all the options you need to configure
and export a config file.

