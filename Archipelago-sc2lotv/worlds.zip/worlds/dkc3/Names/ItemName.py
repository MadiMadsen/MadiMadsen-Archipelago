# Junk Definitions
one_up_balloon  = "1-Up Balloon"
bear_coin    = "Bear Coin"

# Collectable Definitions
bonus_coin   = "Bonus Coin"
dk_coin      = "DK Coin"
banana_bird  = "Banana Bird"
krematoa_cog = "Krematoa Cog"

# Inventory Definitions
progressive_boat = "Progressive Boat Upgrade"
present          = "Present"
bowling_ball     = "Bowling Ball"
shell            = "Shell"
mirror           = "Mirror"
flower           = "Flupperius Petallus Pongus"
wrench           = "No. 6 Wrench"

# Other Definitions
victory = "Donkey Kong"
