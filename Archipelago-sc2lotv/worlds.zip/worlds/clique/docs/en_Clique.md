# Clique

## What is this game?

Even I don't know.

## Where is the settings page?

The [player settings page for this game](../player-settings) contains all the options you need to configure
and export a config file.

