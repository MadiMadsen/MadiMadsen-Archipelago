# Clique Start Guide

Go to the [Clique Game](http://clique.darkshare.site.nfoservers.com/) and enter the hostname:ip address, 
then your slot name.

Enjoy.