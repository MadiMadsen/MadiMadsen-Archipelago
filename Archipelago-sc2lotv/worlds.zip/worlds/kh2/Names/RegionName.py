LoD_Region                                   ="Land of Dragons"
LoD2_Region                                  ="Land of Dragons 2"

Ag_Region                                    ="Agrabah"
Ag2_Region                                   ="Agrabah 2"

Dc_Region                                    ="Disney Castle"
Tr_Region                                    ="Timeless River"

HundredAcre1_Region                          ="Pooh's House"
HundredAcre2_Region                          ="Piglet's House"
HundredAcre3_Region                          ="Rabbit's House"
HundredAcre4_Region                          ="Roo's House"
HundredAcre5_Region                          ="Spookey Cave"
HundredAcre6_Region                          ="Starry Hill"

Pr_Region                                    ="Port Royal"
Pr2_Region                                   ="Port Royal 2"
Gr2_Region                                   ="Grim Reaper 2"

Oc_Region                                    ="Olympus Coliseum"
Oc2_Region                                   ="Olympus Coliseum 2"
Oc2_pain_and_panic_Region                    ="Pain and Panic Cup"
Oc2_titan_Region                             ="Titan Cup"
Oc2_cerberus_Region                          ="Cerberus Cup"
Oc2_gof_Region                               ="Goddest of Fate Cup"
Oc2Cups_Region                               ="Olympus Coliseum Cups"
HadesCups_Region                             ="Olympus Coliseum Hade's Paradox"

Bc_Region                                    ="Beast's Castle"
Bc2_Region                                   ="Beast's Castle 2"
Xaldin_Region                                ="Xaldin"

Sp_Region                                    ="Space Paranoids"
Sp2_Region                                   ="Space Paranoids 2"
Mcp_Region                                   ="Master Control Program"

Ht_Region                                    ="Holloween Town"
Ht2_Region                                   ="Holloween Town 2"

Hb_Region                                    ="Hollow Bastion"
Hb2_Region                                   ="Hollow Bastion 2"
ThousandHeartless_Region                     ="Thousand Hearless"
Mushroom13_Region                            ="Mushroom 13"
CoR_Region                                   ="Cavern of Rememberance"
Transport_Region                             ="Transport to Rememberance"

Pl_Region                                    ="Pride Lands"
Pl2_Region                                   ="Pride Lands 2"

STT_Region                                   ="Simulated Twilight Town"

TT_Region                                    ="Twlight Town"
TT2_Region                                   ="Twlight Town 2"
TT3_Region                                   ="Twlight Town 3"

Twtnw_Region                                 ="The World That Never Was (First Visit)"
Twtnw_PostRoxas                              ="The World That Never Was (Post Roxas)"
Twtnw_PostXigbar                             ="The World That Never Was (Post Xigbar)"
Twtnw2_Region                                ="The World That Never Was (Second Visit)"  #before riku transformation

SoraLevels_Region                            ="Sora's Levels"
GoA_Region                                   ="Garden Of Assemblage"
Keyblade_Region                              ="Keyblade Slots"

Valor_Region                                 ="Valor Form"
Wisdom_Region                                ="Wisdom Form"
Limit_Region                                 ="Limit Form"
Master_Region                                ="Master Form"
Final_Region                                 ="Final Form"

Terra_Region                                 ="Lingering Will"
Sephi_Region                                 ="Sephiroth"
Marluxia_Region                              ="Marluxia"
Larxene_Region                               ="Larxene"
Vexen_Region                                 ="Vexen"
Lexaeus_Region                               ="Lexaeus"
Zexion_Region                                ="Zexion"

LevelsVS1                                    ="Levels Region (1 Visit Locking Item)"
LevelsVS3                                    ="Levels Region (3 Visit Locking Items)"
LevelsVS6                                    ="Levels Region (6 Visit Locking Items)"
LevelsVS9                                    ="Levels Region (9 Visit Locking Items)"
LevelsVS12                                    ="Levels Region (12 Visit Locking Items)"
LevelsVS15                                    ="Levels Region (15 Visit Locking Items)"
LevelsVS18                                    ="Levels Region (18 Visit Locking Items)"
LevelsVS21                                    ="Levels Region (21 Visit Locking Items)"
LevelsVS24                                    ="Levels Region (24 Visit Locking Items)"
LevelsVS26                                    ="Levels Region (26 Visit Locking Items)"

