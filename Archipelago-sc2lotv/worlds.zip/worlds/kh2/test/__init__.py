from test.TestBase import WorldTestBase


class KH2TestBase(WorldTestBase):
    game = "Kingdom Hearts 2"
