from test.TestBase import WorldTestBase


class MessengerTestBase(WorldTestBase):
    game = "The Messenger"
    player: int = 1
