import typing
from Options import Option


checksfinder_options: typing.Dict[str, type(Option)] = {
}
