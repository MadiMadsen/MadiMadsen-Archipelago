from test.TestBase import WorldTestBase
from ..Common import LINKS_AWAKENING
class LADXTestBase(WorldTestBase):
    game = LINKS_AWAKENING
