from .droppedKey import DroppedKey


class AnglerKey(DroppedKey):
    def __init__(self):
        super().__init__(0x0CE)