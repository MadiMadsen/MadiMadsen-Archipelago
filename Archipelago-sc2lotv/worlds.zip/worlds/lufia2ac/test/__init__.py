from test.TestBase import WorldTestBase


class L2ACTestBase(WorldTestBase):
    game = "Lufia II Ancient Cave"
